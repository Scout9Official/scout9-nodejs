
/**
 * Required core entity type: Agents represents you and your team
 * @returns {Array<Agent>}
 */
export default function Agents() {
  return [
  {
    "id": "c8LyZzZsGRSU4B16iW5zOMkiUUm2",
    "firstName": "Patrick",
    "lastName": "Opie",
    "programmablePhoneNumber": "+12066564253",
    "programmablePhoneNumberSid": "PN34d162aa85f86001c56ef4a9353ed918",
    "programmableEmail": "patrick@scout9.com",
    "forwardPhone": "+14254460552",
    "title": "Trial pocket scout agent",
    "context": "Trial pocket scout agent"
  }
];
}
