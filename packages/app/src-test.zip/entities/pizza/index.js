
/**
 * Example entity to help us differentiate if a user wants a delivery or pickup order
 * @returns {IEntityBuildConfig}
 */
export default async function pizzaEntity() {
  return {
  "definitions": [
    {
      "utterance": "quantity",
      "value": "number",
      "text": []
    },
    {
      "utterance": "size",
      "value": "small",
      "text": [
        "small",
        "sm",
        "6 inch",
        "6-inch",
        "6in",
        "6 in",
        "6\""
      ]
    },
    {
      "utterance": "size",
      "value": "medium",
      "text": [
        "medium",
        "med",
        "md",
        "8 inch",
        "8-inch",
        "8in",
        "8 in",
        "8\""
      ]
    },
    {
      "utterance": "size",
      "value": "large",
      "text": [
        "large",
        "lg",
        "12 inch",
        "12-inch",
        "12in",
        "12 in",
        "12\""
      ]
    },
    {
      "utterance": "size",
      "value": "x-large",
      "text": [
        "extra large",
        "x-large",
        "xlarge",
        "xl",
        "16 inch",
        "16-inch",
        "16in",
        "16 in",
        "16\""
      ]
    },
    {
      "utterance": "topping",
      "value": "pepperoni",
      "text": [
        "pepperoni"
      ]
    },
    {
      "utterance": "topping",
      "value": "sausage",
      "text": [
        "sausage",
        "italian sausage"
      ]
    },
    {
      "utterance": "topping",
      "value": "mushroom",
      "text": [
        "mushroom",
        "mushrooms",
        "mush"
      ]
    },
    {
      "utterance": "topping",
      "value": "cheese",
      "text": [
        "cheese",
        "cheesy",
        "cheez",
        "mozarella",
        "mozzarella",
        "mozz"
      ]
    }
  ],
  "training": [
    {
      "text": "{{quantity:number}} %topping% %size%",
      "intent": "pizza"
    },
    {
      "text": "{{quantity:number}} %topping% %size%, {{quantity:number}} %topping% %size%, and {{quantity:number}} %topping% %size% and that should be all",
      "intent": "pizza"
    },
    {
      "text": "Hey I would like {{quantity:number}} %topping% %size%",
      "intent": "pizza"
    },
    {
      "text": "Hey I would like {{quantity:number}} %topping% and %topping%",
      "intent": "pizza"
    },
    {
      "text": "Hey I would like {{quantity:number}} %topping%, %topping%, and extra %topping%",
      "intent": "pizza"
    },
    {
      "text": "Hey I would like {{quantity:number}} %size% %topping%, %topping%, and %topping%",
      "intent": "pizza"
    },
    {
      "text": "Could I get a %topping% pizza please?",
      "intent": "pizza"
    },
    {
      "text": "Could I get {{quantity:number}} %size% %topping%, %topping%, and %topping%?",
      "intent": "pizza"
    },
    {
      "text": "Can I order a {{quantity:number}} %size% %topping%, %topping%, and %topping%",
      "intent": "pizza"
    },
    {
      "text": "Can you remove that %size% %topping% pizza",
      "intent": "remove_pizza"
    },
    {
      "text": "Can you remove that %topping% %size% pizza",
      "intent": "remove_pizza"
    },
    {
      "text": "Can you cancel that %size% %topping%",
      "intent": "remove_pizza"
    },
    {
      "text": "Let's remove that %size% %topping% pizza",
      "intent": "remove_pizza"
    },
    {
      "text": "Let's get rid of that %size% %topping%",
      "intent": "remove_pizza"
    },
    {
      "text": "Let's remove the %size% %topping% pizza",
      "intent": "remove_pizza"
    },
    {
      "text": "Can you remove those %topping%?",
      "intent": "remove_topping"
    },
    {
      "text": "Can you remove that %topping%?",
      "intent": "remove_topping"
    },
    {
      "text": "Actually, no  %topping%?",
      "intent": "remove_topping"
    },
    {
      "text": "Sorry, I don't want  %topping%?",
      "intent": "remove_topping"
    },
    {
      "text": "Do you have %topping%?",
      "intent": "pizza_question"
    }
  ],
  "tests": [
    {
      "text": "I would like 3 pepperoni medium, 2 cheese medium, and 3 sausage mushroom",
      "expected": {
        "intent": "pizza",
        "context": {
          "pizza": [
            {
              "quantity": 3,
              "topping": "pepperoni",
              "size": "medium"
            },
            {
              "quantity": 2,
              "topping": "cheese",
              "size": "medium"
            },
            {
              "quantity": 3,
              "topping": [
                "sausage",
                "mushroom"
              ]
            }
          ]
        }
      }
    },
    {
      "text": "Hey I would like 3 medium pepperoni, sausage, and extra cheese",
      "expected": {
        "intent": "pizza",
        "context": {
          "pizza": [
            {
              "quantity": 3,
              "topping": [
                "pepperoni",
                "sausage",
                "cheese"
              ],
              "size": "medium"
            }
          ]
        }
      }
    }
  ]
};
}
