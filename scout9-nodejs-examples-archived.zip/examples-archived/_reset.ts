import { reset } from './_utils';

(async () => {
  await reset();
})();
